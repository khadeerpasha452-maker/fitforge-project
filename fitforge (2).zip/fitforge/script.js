// ---------- Config ----------
const MET = {Running:8, Cycling:7, 'Push-ups':6, Gym:5};
const INT = {Low:0.8, Moderate:1, High:4/3};
const MAX_MIN_PER_DAY = 180, MAX_PTS_PER_WORKOUT = 600, COOLDOWN_MS = 5000;
const WEEKLY_GOAL = 1500, BOSS_HP = 4000, KEY = 'fitforge_v1';
const BADGES = [
  {id:'first', ic:'🔥', n:'First Sweat', d:'Log your first workout', f:w=>w.length>=1},
  {id:'r5', ic:'🏃', n:'5k Trailblazer', d:'Run 5 km or more', f:w=>w.some(x=>x.type=='Running'&&x.km>=5)},
  {id:'r10', ic:'🏅', n:'10k Runner', d:'Run 10 km or more', f:w=>w.some(x=>x.type=='Running'&&x.km>=10)},
  {id:'con', ic:'💪', n:'Consistency Beast', d:'Log 10 workouts', f:w=>w.length>=10},
  {id:'str', ic:'⚡', n:'7-Day Streak', d:'Work out 7 days in a row', f:w=>streak(w)>=7},
  {id:'pow', ic:'💥', n:'Power Surge', d:'250+ points in one workout', f:w=>w.some(x=>x.pts>=250)},
  {id:'gym', ic:'🏋️', n:'Iron Pumper', d:'Log 3 gym sessions', f:w=>w.filter(x=>x.type=='Gym').length>=3},
  {id:'hero', ic:'🛡️', n:'Squad Hero', d:'Earn 500 total points', f:w=>w.reduce((a,x)=>a+x.pts,0)>=500},
];

// ---------- Helpers ----------
const iso = d => d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const dayAgo = n => { const d = new Date(); d.setDate(d.getDate()-n); return iso(d); };
const calc = (type, min, inten) => Math.round(min * MET[type] * INT[inten]);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const $ = id => document.getElementById(id);
function streak(ws){
  const days=[...new Set(ws.map(w=>w.day))].sort(); let best=0,run=0,prev=null;
  for(const d of days){
    run = prev && Math.round((new Date(d+'T00:00')-new Date(prev+'T00:00'))/864e5)===1 ? run+1 : 1;
    best=Math.max(best,run); prev=d;
  }
  return best;
}

// ---------- Seed data: 5 squads, 20 members ----------
function seed(){
  let r=7; const rnd=()=>(r=(r*9301+49297)%233280)/233280;
  const squads=[['Iron Legion','IRON01',1850],['Neon Wolves','WOLF22',2100],['Pulse Pirates','PIRA33',1500],['Sprint Sharks','SHRK44',1200],['Zen Zealots','ZENZ55',900]]
    .map((s,i)=>({id:'s'+i,name:s[0],code:s[1],goal:WEEKLY_GOAL,pts:0,target:s[2]}));
  const names=['Alex','Maya','Ravi','Zoe','Kai','Lena','Omar','Priya','Jin','Sara','Leo','Nina','Arjun','Tess','Marco','Ines','Dev','Cleo','Sam','Yuki'];
  const users=[],workouts=[]; let wid=1;
  names.forEach((n,i)=>users.push({id:i==0?'me':'u'+i,name:i==0?'You':n,sq:'s'+Math.floor(i/4)}));
  const types=Object.keys(MET), ints=Object.keys(INT);
  squads.forEach(s=>{
    let sum=0, first=null;
    users.filter(u=>u.sq==s.id).forEach(u=>{
      first=first||u;
      for(let d=6; d>=0; d--) if(rnd()<0.4){
        const type=types[Math.floor(rnd()*4)], int=ints[Math.floor(rnd()*3)], min=20+Math.floor(rnd()*10);
        const km=(type=='Running'||type=='Cycling')?Math.round(min/6*10)/10:0, pts=calc(type,min,int);
        workouts.push({id:wid++,u:u.id,type,min,km,int,pts,day:dayAgo(d),t:Date.now()-d*864e5});
        sum+=pts;
      }
    });
    // "legacy" workout pads each squad to its target total
    workouts.push({id:wid++,u:first.id,type:'Gym',min:60,km:0,int:'Moderate',pts:Math.max(0,s.target-sum),day:dayAgo(20),t:Date.now()-20*864e5});
    s.pts=Math.max(s.target,sum);
  });
  return {users,squads,workouts,hi:{},wid};
}
function load(){ try{ return JSON.parse(localStorage.getItem(KEY)); }catch(e){ return null; } }
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }

// ---------- State & selectors ----------
let S = load() || seed(), per = 29, lastLog = 0, charts = {};
const me = () => S.users.find(u=>u.id=='me');
const mySq = () => S.squads.find(s=>s.id==me().sq);
const members = sq => S.users.filter(u=>u.sq==sq);
const wsOf = u => S.workouts.filter(w=>w.u==u);
const uName = id => (S.users.find(u=>u.id==id)||{name:'?'}).name;
const sqPts = (sq,n=9999) => { const ids=members(sq).map(u=>u.id), from=dayAgo(n);
  return S.workouts.filter(w=>ids.includes(w.u)&&w.day>=from).reduce((a,w)=>a+w.pts,0); };
const ranked = n => S.squads.filter(s=>members(s.id).length>=4).map(s=>({s,p:sqPts(s.id,n)})).sort((a,b)=>b.p-a.p);
const myRank = n => { const i=ranked(n).findIndex(x=>x.s.id==me().sq); return i<0?0:i+1; };
const earned = u => new Set(BADGES.filter(b=>b.f(wsOf(u))).map(b=>b.id));
const ord = n => n+(['th','st','nd','rd'][(n%100>10&&n%100<14)?0:Math.min(n%10,4)%4]||'th');

// ---------- Render ----------
function render(){
  const sq=mySq(), rk=myRank(per), cnt=members(sq.id).length, wk=sqPts(sq.id,6);
  $('who').textContent = me().name;
  $('dash').innerHTML = `
    <h2>${esc(sq.name)}</h2>
    <div class="mu">Invite code <b>${esc(sq.code)}</b> · ${cnt} of 6 members ${cnt<4?'<span class="tag">Forming: needs 4 to compete</span>':''}</div>
    <div class="big" style="margin:.8rem 0 .2rem">${rk?ord(rk)+' place':'Unranked'}</div>
    <div class="mu">${sq.pts.toLocaleString()} total points</div>
    <h3 style="margin-top:1rem">Weekly team goal</h3>
    <div class="bar"><i style="width:${Math.min(100,wk/sq.goal*100)}%"></i></div>
    <div class="mu">${wk} / ${sq.goal} points this week</div>
    <h3 style="margin-top:1rem">Boss battle: Lord Lazybones 👹</h3>
    <div class="bar boss"><i style="width:${Math.max(0,100-wk/BOSS_HP*100)}%"></i></div>
    <div class="mu">${Math.max(0,BOSS_HP-wk)} HP left. Defeat him before Sunday midnight.</div>`;

  $('lbSquads').innerHTML = ranked(per).map((x,i)=>`
    <div class="lb ${x.s.id==sq.id?'mine':''}"><span>${i+1}. ${esc(x.s.name)}</span><b>${x.p.toLocaleString()}</b></div>`).join('');
  const from=dayAgo(per);
  $('lbMembers').innerHTML = members(sq.id).map(u=>({u,p:wsOf(u.id).filter(w=>w.day>=from).reduce((a,w)=>a+w.pts,0)}))
    .sort((a,b)=>b.p-a.p).map((x,i)=>`<div class="lb ${x.u.id=='me'?'mine':''}"><span>${i+1}. ${esc(x.u.name)}</span><b>${x.p}</b></div>`).join('');
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('on', +b.dataset.n===per));

  const got=earned('me');
  $('badges').innerHTML = BADGES.map(b=>`<div class="bd ${got.has(b.id)?'on':'off'}"><span class="ic">${b.ic}</span><b>${b.n}</b><div class="mu">${b.d}</div></div>`).join('');

  const ids=members(sq.id).map(u=>u.id);
  $('feed').innerHTML = S.workouts.filter(w=>ids.includes(w.u)).sort((a,b)=>b.t-a.t).slice(0,10).map(w=>`
    <div class="feed"><span><b>${esc(uName(w.u))}</b> did ${w.min} min ${w.type}${w.km?' ('+w.km+' km)':''}, ${w.int.toLowerCase()} intensity <span class="tag">+${w.pts} pts</span></span>
    <button class="sm" data-hi="${w.id}">🙌 ${S.hi[w.id]||0}</button></div>`).join('') || '<p class="mu">No workouts yet. Log one to start the feed.</p>';

  drawCharts(ids);
  updatePreview();
}
function drawCharts(ids){
  if(typeof Chart==='undefined') return;
  const days=[...Array(7)].map((_,i)=>dayAgo(6-i)), labels=days.map(d=>d.slice(5));
  const mine=days.map(d=>wsOf('me').filter(w=>w.day==d).reduce((a,w)=>a+w.pts,0));
  const team=days.map(d=>S.workouts.filter(w=>ids.includes(w.u)&&w.day==d).reduce((a,w)=>a+w.pts,0));
  const opt=t=>({responsive:true,maintainAspectRatio:false,plugins:{title:{display:true,text:t,color:'#eef1f5'},legend:{labels:{color:'#9aa5b5'}}},
    scales:{x:{ticks:{color:'#9aa5b5'},grid:{color:'#2d3644'}},y:{beginAtZero:true,ticks:{color:'#9aa5b5'},grid:{color:'#2d3644'}}}});
  Object.values(charts).forEach(c=>c.destroy());
  charts.a=new Chart($('c1'),{type:'bar',data:{labels,datasets:[{label:'Your points',data:mine,backgroundColor:'#ff5a36'}]},options:opt('Your daily points')});
  charts.b=new Chart($('c2'),{type:'line',data:{labels,datasets:[{label:'Squad points',data:team,borderColor:'#3ddc97',backgroundColor:'#3ddc9733',fill:true,tension:.3}]},options:opt('Squad daily points')});
}
function updatePreview(){
  const m=+$('min').value||0;
  $('preview').textContent = m>0 ? `Points = ${m} min × MET ${MET[$('type').value]} × intensity ${INT[$('int').value].toFixed(2)} = ${calc($('type').value,m,$('int').value)}` : '';
}
function toast(msg){ const t=$('toast'); t.textContent=msg; t.style.display='block'; clearTimeout(t._h); t._h=setTimeout(()=>t.style.display='none',4500); }

// ---------- Actions ----------
$('logBtn').onclick = () => {
  const type=$('type').value, inten=$('int').value, min=Math.round(+$('min').value), km=Math.max(0,+$('km').value||0), err=$('err');
  err.textContent='';
  if(!(min>0)) return err.textContent='Enter a duration of at least 1 minute.';
  const today=dayAgo(0), logged=wsOf('me').filter(w=>w.day==today).reduce((a,w)=>a+w.min,0);
  if(logged+min>MAX_MIN_PER_DAY) return err.textContent=`Daily limit is ${MAX_MIN_PER_DAY} minutes. You have ${Math.max(0,MAX_MIN_PER_DAY-logged)} left today.`;
  if(Date.now()-lastLog<COOLDOWN_MS) return err.textContent='Slow down. Wait a few seconds between logs.';
  const before=earned('me'), rankBefore=myRank(per);
  const pts=Math.min(MAX_PTS_PER_WORKOUT, calc(type,min,inten));
  S.workouts.push({id:++S.wid,u:'me',type,min,km:(type=='Running'||type=='Cycling')?km:0,int:inten,pts,day:today,t:Date.now()});
  mySq().pts += pts; lastLog=Date.now(); save(); render();
  const nb=BADGES.filter(b=>earned('me').has(b.id)&&!before.has(b.id)).map(b=>b.ic+' '+b.n);
  const rk=myRank(per);
  toast(`+${pts} points!`+(nb.length?` Badge unlocked: ${nb.join(', ')}.`:'')+(rk&&rankBefore&&rk<rankBefore?` ${mySq().name} moved up to ${ord(rk)} place!`:''));
};
['type','int','min'].forEach(id=>$(id).addEventListener('input',updatePreview));
$('tabs').onclick = e => { if(e.target.dataset.n){ per=+e.target.dataset.n; render(); } };
$('feed').onclick = e => { const id=e.target.dataset.hi; if(id){ S.hi[id]=(S.hi[id]||0)+1; save(); render(); } };
$('reset').onclick = () => { S=seed(); save(); render(); };
function moveTo(sq){ const old=mySq(); me().sq=sq.id; [old,sq].forEach(s=>s.pts=sqPts(s.id)); save(); render(); }
$('join').onclick = () => {
  const c=$('code').value.trim().toUpperCase(), sq=S.squads.find(s=>s.code==c), e=$('sqErr'); e.textContent='';
  if(!sq) return e.textContent='No squad has that code.';
  if(sq.id==me().sq) return e.textContent='You are already in this squad.';
  if(members(sq.id).length>=6) return e.textContent='That squad is full (6 members max).';
  moveTo(sq); toast('Joined '+sq.name+'!');
};
$('create').onclick = () => {
  const n=$('newName').value.trim(), e=$('sqErr'); e.textContent='';
  if(n.length<3) return e.textContent='Squad name needs at least 3 characters.';
  const sq={id:'s'+Date.now(),name:n,code:Math.random().toString(36).slice(2,7).toUpperCase(),goal:WEEKLY_GOAL,pts:0};
  S.squads.push(sq); moveTo(sq); toast(`${n} created. Share code ${sq.code} to invite friends.`);
};
render();
