# FitForge: SweatSquad Showdown

Open `index.html` in a browser (internet needed for Chart.js and fonts).

Files: index.html, style.css, script.js. Data is stored in localStorage; use 'Reset demo data' to restart.

Demo: log Running, 30 min, 5 km, High = 320 pts, unlocks 5k Trailblazer and lifts Iron Legion to 1st.
